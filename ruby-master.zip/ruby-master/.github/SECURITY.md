# Security Policy

## Supported Versions

See <https://www.ruby-lang.org/en/downloads/branches/>.

## Reporting a Vulnerability

See <https://www.ruby-lang.org/en/security/>.
