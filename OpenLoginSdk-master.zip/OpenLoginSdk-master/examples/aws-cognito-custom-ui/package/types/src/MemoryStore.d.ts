import { IStore } from "./IStore";
export declare class MemoryStore implements IStore {
    store: Record<string, string>;
    getItem(key: string): string;
    setItem(key: string, value: string): void;
}
