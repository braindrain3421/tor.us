# OpenLogin ED25519

OpenLogin is a plug & play authentication suite that combines the simplicity of passwordless authentication with the security of non-custodial public key infrastructure (PKI).

OpenLogin ED25519 helps developers generate ed25519 (tweetnacl-compatible) signing keys.

Head over to [docs](https://docs.tor.us/open-login/get-started) to get started.
