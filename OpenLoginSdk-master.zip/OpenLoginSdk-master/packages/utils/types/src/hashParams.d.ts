export declare class HashParams extends URLSearchParams {
}
