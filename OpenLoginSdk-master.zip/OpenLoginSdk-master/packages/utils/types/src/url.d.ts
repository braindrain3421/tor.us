import { HashParams } from "./hashParams";
export declare class URLWithHashParams extends URL {
    hashParams: HashParams;
    toString(): string;
}
