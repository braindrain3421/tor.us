export declare const randomId: () => string;
