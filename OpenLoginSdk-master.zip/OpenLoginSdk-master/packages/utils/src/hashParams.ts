export class HashParams extends URLSearchParams {}
