# OpenLogin Utils

OpenLogin is a plug & play authentication suite that combines the simplicity of passwordless authentication with the security of non-custodial public key infrastructure (PKI).

OpenLogin utils contains supporting utility functions for OpenLogin.

Head over to [docs](https://docs.tor.us/open-login/get-started) to get started.
