/// <reference types="node" />
export declare const SECP256K1_CURVE_N = "fffffffffffffffffffffffffffffffebaaedce6af48a03bbfd25e8cd0364141";
export declare function subkey(keyHex: string, input: Buffer): string;
