# OpenLogin JRPC

OpenLogin is a plug & play authentication suite that combines the simplicity of passwordless authentication with the security of non-custodial public key infrastructure (PKI).

OpenLogin JRPC contains rpc method implementations that are used on [openlogin](https://app.openlogin.com) for managing authentication flows for the user.

Head over to [docs](https://docs.tor.us/open-login/get-started) to get started.
