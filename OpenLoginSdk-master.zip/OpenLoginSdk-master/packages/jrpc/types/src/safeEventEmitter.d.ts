/// <reference types="node" />
import { EventEmitter } from "events";
export default class SafeEventEmitter extends EventEmitter {
    emit(type: string, ...args: any[]): boolean;
}
