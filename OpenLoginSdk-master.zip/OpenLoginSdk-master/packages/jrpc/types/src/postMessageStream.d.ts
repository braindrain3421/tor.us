import BasePostMessageStream from "./basePostMessageStream";
export default class PostMessageStream extends BasePostMessageStream {
    _postMessage(data: unknown): void;
}
